# 人手锚点版 —— 精简备份（2026-09-30）

这一份**只保留「人手起手」这一条线**，双击 `人手起手.bat` 就能跑，
不需要原项目里那一堆旧脚本。

## 它做什么

1. 你选歌（回车 = 影色舞 EASY，也可以输关键字或曲目号）；
2. 脚本替你点 LIVE START，趁加载页用虚拟触摸屏自点几下，
   量一次「发一条触摸 → getevent 读到」的往返延迟；
3. 演奏画面出来后，**你按第 1 个音符**；
4. 脚本取那条触摸事件的**内核时间戳**当基准，从**第 2 个音符**开始注入。

关键点：用内核时间戳当锚点，「读取慢」只会让我们晚一点开打，不会让落点偏。
不再依赖「猜起播时刻」那套（实测同一套逻辑标定值在 2.12s / 9.53s / 10.05s /
11.52s 之间跳，是之前跑偏的根源）。

## 文件清单

| 路径 | 作用 |
|---|---|
| `人手起手.bat` | 入口 |
| `tools/human_play.py` | 选歌 → 点开始 → 等第一下 → 从第二下接管 |
| `tools/live_start_template.png` | 认「乐队确认页」的按钮模板 |
| `tools/scrcpy/scrcpy-server-v4.1` | UHID 虚拟触摸屏用的服务端 |
| `src/bandori_autoplay/human_anchor.py` | 实时触摸读取、往返延迟标定、锚点换算 |
| `src/bandori_autoplay/uhid_touch.py` | UHID 虚拟触摸屏（非 root） |
| `config/default.yaml` | 设备坐标、判定线、触控后端等 |
| `work/chartdb/out/` | 340 张谱面（含 `index.json`） |
| `work/master/MasterText.json` | 曲名的文本表（选歌列表要用） |

## 日志

跑起来的输出会同步写到 `logs\human_play_日期_时间.log`（行缓冲，中断也留得下）。

## 两个坑，已修

* **中文路径**：`cv2.imread` 在 Windows 上读不了含中文的路径（`liveui.template()`
  会静默失败 → 认不出确认页 → 往右下角乱点）。现在模板读取改走
  `imdecode + np.fromfile`，任何路径都能读。备份目录名也改成了纯 ASCII。
* **日志缓冲**：原来是块缓冲，进程被中断时日志文件是空的；现在行缓冲。

## 换机器/换手机要改什么

`config/default.yaml` 里的 `device.adb_path` 是本机的 adb 绝对路径，
换机器要改成自己的。
